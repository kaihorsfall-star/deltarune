# Online backend setup notes

The current `index.html` saves its demo data in the browser's `localStorage`. It does not yet use Supabase to authenticate users or read/write shared messages, even if connection settings are saved.

For a real multi-user deployment:

1. Create a Supabase project.
2. Review and run `supabase-setup.sql` in the SQL Editor.
3. Configure Supabase Auth and suitable sign-in methods.
4. Update the website to use Supabase Auth, profile/message queries, and Realtime subscriptions.
5. Add and test stricter policies, spam/rate protections, input validation, account deletion, and privacy controls.
6. Implement a shared signaling service and TURN/STUN configuration if you want reliable WebRTC voice calls.

The included SQL is only a starting point. In particular, the broad profile-read policy may expose profile information to every authenticated user; tighten it for your use case. Never expose a service-role key in client-side HTML.
