# KAI CHAT

A single-page browser chat demo with profile settings, local accounts/messages, and built-in mini-games.

## Project structure

- `index.html` — the website. Open it in a browser or publish it with GitHub Pages.
- `supabase-setup.sql` — starter database schema for a future shared online backend.
- `docs/ONLINE-SETUP.md` — notes for preparing an online version.

## Run locally

Open `index.html` in a modern browser. The current app stores its demo data in that browser's `localStorage`.

## Publish on GitHub Pages

1. Extract this ZIP.
2. Create a GitHub repository and upload `index.html` (and optionally the other project files).
3. In the repository, open **Settings → Pages**.
4. Choose the branch and root folder, then save.
5. Open the published Pages URL.

## Important limitation

This project is currently a browser-local demo. Accounts and messages saved in `localStorage` are only available in that browser on that device; they are not shared with other users or devices. The settings panel contains starter Supabase setup guidance, but saving a project URL/key does not by itself implement online authentication, shared messaging, friends/groups, or voice-call signaling.

Do not put a Supabase service-role key in browser code. Before making a public online service, implement Supabase Auth, database operations, Realtime subscriptions, and strict Row Level Security policies, then test the security rules.
