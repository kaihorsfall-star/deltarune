# KaiChat — shared chat with accounts

This project includes separate account pages (`/register` and `/login.html`) and the main community chat (`/chat`). It uses a real server and SQLite database so accounts and messages are shared by everyone using the same hosted instance.

## Run locally

1. Install **Node.js 20 or newer**.
2. Unzip the project and open a terminal in the `kaichat` folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Set `SESSION_SECRET` in `.env` to a long, random secret (32+ characters).
6. Run `npm start`.
7. Open `http://localhost:3000`.

## Important details

- Nicknames are unique, case-insensitively.
- Passwords are stored as bcrypt hashes; the original password is never stored as readable text.
- Logging in can be kept active for 14 days via an HTTP-only session cookie. Users can choose to let their browser save the password in its password manager.
- Account records and chat messages persist in `data/kaichat.sqlite`; session records are stored in `data/sessions.sqlite`.
- For shared chat, deploy the server on a Node.js hosting service that supports persistent disk/database storage. **GitHub Pages alone cannot run this backend**, because it only hosts static files.
- For production, use HTTPS and set `NODE_ENV=production` and a strong `SESSION_SECRET`.
- This is a starting project; add moderation, abuse prevention, backups, and operational monitoring before opening it to a large public audience.

## Pages and API

- `/` — welcome page
- `/register` — create account
- `/login.html` — log in
- `/chat` — shared community chat
- `/api/auth/register`, `/api/auth/login`, `/api/auth/logout`
- `/api/me`
- `/api/messages`

## Troubleshooting

If login says it cannot connect, ensure the Node server is running and that you opened the hosted URL (not a local HTML file via `file://`). All users must use the same deployed server URL to see one another's messages.
