const express = require('express');
const session = require('express-session');
const SQLiteStoreFactory = require('connect-sqlite3');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';
const secret = process.env.SESSION_SECRET;
if (isProduction && (!secret || secret.length < 32)) {
  throw new Error('Set SESSION_SECRET to a random string of at least 32 characters in production.');
}
const sessionSecret = secret || 'development-only-secret-change-before-deploying-please';
const dataDir = path.join(__dirname, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'kaichat.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nickname TEXT NOT NULL,
    nickname_key TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    nickname TEXT NOT NULL,
    body TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE INDEX IF NOT EXISTS messages_id_idx ON messages(id);
`);

const SQLiteStore = SQLiteStoreFactory(session);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: {
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'"],
    styleSrc: ["'self'"],
    imgSrc: ["'self'", 'data:', 'https:'],
    connectSrc: ["'self'"],
    frameAncestors: ["'none'"],
    objectSrc: ["'none'"],
    upgradeInsecureRequests: isProduction ? [] : null
  }
}}));
app.use(express.json({ limit: '12kb' }));
app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: dataDir, concurrentDB: true }),
  name: 'kaichat.sid',
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: isProduction,
    maxAge: 1000 * 60 * 60 * 24 * 14
  }
}));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));
app.use('/api/messages', rateLimit({ windowMs: 60 * 1000, limit: 90, standardHeaders: true, legacyHeaders: false }));

function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: 'Please log in to continue.' });
  next();
}
function publicUser(user) {
  return { id: user.id, nickname: user.nickname };
}

app.post('/api/auth/register', async (req, res, next) => {
  try {
    const nickname = typeof req.body.nickname === 'string' ? req.body.nickname.trim() : '';
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    if (!/^[\p{L}\p{N}_ -]{3,24}$/u.test(nickname)) {
      return res.status(400).json({ error: 'Nickname must be 3–24 characters and use letters, numbers, spaces, _ or -.' });
    }
    if (password.length < 8 || password.length > 128) {
      return res.status(400).json({ error: 'Password must be at least 8 characters (maximum 128).' });
    }
    const nicknameKey = nickname.toLocaleLowerCase('en-US');
    const passwordHash = await bcrypt.hash(password, 12);
    try {
      const result = db.prepare('INSERT INTO users(nickname, nickname_key, password_hash) VALUES (?, ?, ?)')
        .run(nickname, nicknameKey, passwordHash);
      req.session.regenerate(err => {
        if (err) return next(err);
        req.session.user = { id: Number(result.lastInsertRowid), nickname };
        req.session.save(err2 => {
          if (err2) return next(err2);
          res.status(201).json({ user: req.session.user });
        });
      });
    } catch (err) {
      if (String(err.code).includes('SQLITE_CONSTRAINT_UNIQUE')) {
        return res.status(409).json({ error: 'That nickname is already taken. Choose another.' });
      }
      throw err;
    }
  } catch (err) { next(err); }
});

app.post('/api/auth/login', async (req, res, next) => {
  try {
    const nickname = typeof req.body.nickname === 'string' ? req.body.nickname.trim() : '';
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    if (!nickname || !password) return res.status(400).json({ error: 'Enter both nickname and password.' });
    const user = db.prepare('SELECT * FROM users WHERE nickname_key = ?').get(nickname.toLocaleLowerCase('en-US'));
    // A dummy hash keeps the missing-user path closer to the normal password-check path.
    const hash = user ? user.password_hash : '$2a$12$C6UzMDM.H6dfI/f/IKcEe.5p8D6L1JfH2vP9sW7u3k6bQ4Z5xG2f2';
    const valid = await bcrypt.compare(password, hash).catch(() => false);
    if (!user || !valid) return res.status(401).json({ error: 'Incorrect nickname or password.' });
    req.session.regenerate(err => {
      if (err) return next(err);
      req.session.user = publicUser(user);
      req.session.save(err2 => {
        if (err2) return next(err2);
        res.json({ user: req.session.user });
      });
    });
  } catch (err) { next(err); }
});

app.post('/api/auth/logout', (req, res, next) => {
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie('kaichat.sid', { httpOnly: true, sameSite: 'lax', secure: isProduction });
    res.json({ ok: true });
  });
});
app.get('/api/me', (req, res) => res.json({ user: req.session.user || null }));

app.get('/api/messages', requireAuth, (req, res) => {
  const after = Math.max(0, Number.parseInt(req.query.after || '0', 10) || 0);
  const rows = db.prepare(`SELECT id, user_id AS userId, nickname, body, created_at AS createdAt
    FROM messages WHERE id > ? ORDER BY id ASC LIMIT 100`).all(after);
  res.json({ messages: rows });
});
app.post('/api/messages', requireAuth, (req, res) => {
  const body = typeof req.body.body === 'string' ? req.body.body.trim() : '';
  if (!body) return res.status(400).json({ error: 'Message cannot be empty.' });
  if (body.length > 1000) return res.status(400).json({ error: 'Messages must be 1,000 characters or fewer.' });
  const result = db.prepare('INSERT INTO messages(user_id, nickname, body) VALUES (?, ?, ?)')
    .run(req.session.user.id, req.session.user.nickname, body);
  const message = db.prepare(`SELECT id, user_id AS userId, nickname, body, created_at AS createdAt FROM messages WHERE id = ?`)
    .get(Number(result.lastInsertRowid));
  res.status(201).json({ message });
});

app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/register', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'register.html')));
app.get('/chat', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'chat.html')));
app.use((err, req, res, _next) => {
  console.error(err);
  if (res.headersSent) return;
  res.status(500).json({ error: 'Something went wrong on the server. Please try again.' });
});
app.listen(PORT, () => console.log(`KaiChat is running at http://localhost:${PORT}`));
