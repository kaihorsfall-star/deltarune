(() => {
  const $ = s => document.querySelector(s);
  const reg = $('#registerForm'), login = $('#loginForm');
  const form = reg || login;
  if (!form) return;
  const error = $('#error'), button = $('#submit');
  form.addEventListener('submit', async e => {
    e.preventDefault(); error.textContent = '';
    const data = new FormData(form);
    const nickname = String(data.get('nickname') || '').trim();
    const password = String(data.get('password') || '');
    if (reg && password !== String(data.get('confirm') || '')) {
      error.textContent = 'The passwords do not match.'; return;
    }
    button.disabled = true; button.textContent = reg ? 'Creating account…' : 'Logging in…';
    try {
      const response = await fetch(reg ? '/api/auth/register' : '/api/auth/login', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        credentials: 'same-origin', body: JSON.stringify({nickname, password})
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) { error.textContent = result.error || 'Could not complete that request.'; return; }
      window.location.assign('/chat');
    } catch (err) {
      error.textContent = 'Could not connect to KaiChat. Make sure the server is running and try again.';
    } finally {
      button.disabled = false; button.textContent = reg ? 'Create account' : 'Log in';
    }
  });
})();