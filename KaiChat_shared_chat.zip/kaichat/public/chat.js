(() => {
  const $ = s => document.querySelector(s);
  const messagesEl = $('#messages'), form = $('#messageForm'), input = $('#message'), send = $('#send');
  let lastId = 0, polling = false;
  const esc = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function api(url, options={}) {
    const r = await fetch(url, {credentials:'same-origin', ...options});
    if (r.status === 401) { window.location.assign('/login.html'); throw new Error('Please log in again.'); }
    const d = await r.json().catch(()=>({}));
    if (!r.ok) throw new Error(d.error || 'Request failed.');
    return d;
  }
  function render(m) {
    const empty = messagesEl.querySelector('.empty');
    if (empty) empty.remove();
    const item = document.createElement('article');
    item.className = 'message';
    item.innerHTML = `<div class="message-meta"><strong>${esc(m.nickname)}</strong><time>${esc(new Date(m.createdAt.replace(' ','T')+'Z').toLocaleString())}</time></div><p>${esc(m.body)}</p>`;
    messagesEl.appendChild(item);
    lastId = Math.max(lastId, Number(m.id) || 0);
    while (messagesEl.children.length > 250) messagesEl.firstElementChild.remove();
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }
  async function loadMessages() {
    if (polling) return; polling = true;
    try {
      const d = await api('/api/messages?after='+lastId);
      if (!d.messages.length && lastId === 0 && !messagesEl.children.length) messagesEl.innerHTML = '<p class="muted empty">No messages yet. Start the conversation!</p>';
      d.messages.forEach(render);
      $('#error').textContent = '';
    } catch (e) {
      if (e.message !== 'Please log in again.') $('#error').textContent = e.message;
    } finally { polling = false; }
  }
  (async () => {
    try {
      const d = await api('/api/me');
      if (!d.user) { window.location.assign('/login.html'); return; }
      $('#nickname').textContent = d.user.nickname;
      messagesEl.innerHTML = '';
      await loadMessages();
      setInterval(loadMessages, 1800);
    } catch (e) { if (e.message !== 'Please log in again.') $('#error').textContent = e.message; }
  })();
  form.addEventListener('submit', async e => {
    e.preventDefault(); const body = input.value.trim();
    if (!body) return;
    send.disabled = true; $('#error').textContent = '';
    try {
      const d = await api('/api/messages', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({body})});
      input.value = ''; render(d.message); input.focus();
    } catch (e) { $('#error').textContent = e.message; }
    finally { send.disabled = false; }
  });
  $('#logout').addEventListener('click', async () => {
    try { await api('/api/auth/logout', {method:'POST'}); } finally { window.location.assign('/'); }
  });
})();