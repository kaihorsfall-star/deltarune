# NEXUS community app

Runnable Node.js MVP with username/password authentication, SQLite persistence, a coin wallet, daily rewards, HTML5 game publishing/playback, game purchases, global chat, YouTube/Vimeo sharing, profiles, and content reports.

## Run
Requires Node.js 20+.
1. Unzip the project.
2. Run `npm install`.
3. Copy `.env.example` to `.env`, then set `SESSION_SECRET` to a long random value.
4. Run `npm start`.
5. Visit http://localhost:3000.

For real public deployment, use a Node-capable host with persistent disk and HTTPS. GitHub Pages alone cannot run authentication, chat, purchases, or a shared database. This is a runnable MVP, not a fully moderated production-scale service. User-created HTML is untrusted; it is played in a sandboxed iframe. Reports are stored for operator review. Back up `data/nexus.sqlite`.
